/* Marcos Vinícius Firmino Pietrucci 10770072*/

#ifndef MAIN_H
#include"main.h"
#endif
#ifndef STDLIB_H
#include<stdlib.h>
#endif

//Função que inicia o modo 10
void modo10();

//Função que lê as entradas do modo 10
void le_entradas_modo10(char *nome_arq_pessoa, char *nome_arq_index, char *nome_arq_segue);